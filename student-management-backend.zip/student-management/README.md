# Student Management Backend

A beginner-friendly Java backend project built with Spring Boot, MySQL, Spring Data JPA, and REST APIs.

## Features

- Add student
- Get all students
- Get student by ID
- Update student
- Delete student
- Add course
- Get all courses
- Update course
- Delete course
- Validation and exception handling

## Tech Stack

- Java 17
- Spring Boot
- Spring Web
- Spring Data JPA
- MySQL
- Maven
- Lombok

## Project Structure

```text
src/main/java/com/soumya/studentmanagement
├── controller
├── entity
├── exception
├── repository
├── service
└── StudentManagementApplication.java
```

## Database Setup

Create database in MySQL:

```sql
CREATE DATABASE student_management;
```

Update your MySQL password in:

```text
src/main/resources/application.properties
```

```properties
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

## Run Project

```bash
mvn spring-boot:run
```

Server will start at:

```text
http://localhost:8080
```

## Student APIs

### Add Student

```http
POST /api/students
```

Body:

```json
{
  "name": "Virat Kohli",
  "email": "virat@gmail.com",
  "age": 35
}
```

### Get All Students

```http
GET /api/students
```

### Get Student By ID

```http
GET /api/students/1
```

### Update Student

```http
PUT /api/students/1
```

Body:

```json
{
  "name": "Rohit Sharma",
  "email": "rohit@gmail.com",
  "age": 36
}
```

### Delete Student

```http
DELETE /api/students/1
```

## Course APIs

### Add Course

```http
POST /api/courses
```

Body:

```json
{
  "courseName": "Java Backend Development",
  "duration": "3 months",
  "description": "Spring Boot, MySQL and REST API"
}
```

### Get All Courses

```http
GET /api/courses
```

### Get Course By ID

```http
GET /api/courses/1
```

### Update Course

```http
PUT /api/courses/1
```

### Delete Course

```http
DELETE /api/courses/1
```

## GitHub Upload Commands

```bash
git init
git add .
git commit -m "Initial commit - Student Management Backend"
git branch -M main
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

## Future Improvements

- Student-course relationship using foreign key
- Login and registration
- JWT authentication
- Swagger API documentation
- Unit testing
